#!/usr/bin/env python3

from imgproc import openImage
from descriptor import get_descriptors

droite = openImage('droite.jpg')
gauche = openImage('gauche.jpg')

octave = 3
scale = 4


desc = get_descriptors(droite, scale, octave)


